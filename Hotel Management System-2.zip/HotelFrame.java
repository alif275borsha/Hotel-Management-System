import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class HotelFrame extends JFrame implements ActionListener {
    private JTextField nameField, phoneField;
    private JComboBox<String> roomBox;
    private JTextArea displayArea;
    private JButton saveBtn, refreshBtn,deleteBtn,getBtn;

    public HotelFrame() {
        super("Hotel Management System");
        this.setSize(800, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);

        // Left panel for input
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 50, 80, 30);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(130, 50, 150, 30);
        add(nameField);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setBounds(50, 100, 80, 30);
        add(phoneLabel);

        phoneField = new JTextField();
        phoneField.setBounds(130, 100, 150, 30);
        add(phoneField);

        JLabel roomLabel = new JLabel("Room Type:");
        roomLabel.setBounds(50, 150, 100, 30);
        add(roomLabel);

        String[] rooms = {"Single", "Double", "Triple"};
        roomBox = new JComboBox<>(rooms);
        roomBox.setBounds(130, 150, 150, 30);
        add(roomBox);
        saveBtn = new JButton("Insert");
        saveBtn.setBounds(50, 200, 100, 30);
        saveBtn.addActionListener(this);
        add(saveBtn);


        refreshBtn = new JButton("update");
        refreshBtn.setBounds(160, 200, 100, 30);
        refreshBtn.addActionListener(this);
        add(refreshBtn);

        deleteBtn = new JButton("Delete");
        deleteBtn.setBounds(150, 250, 80, 30);
        deleteBtn.addActionListener(this);
        add(deleteBtn);

             getBtn = new JButton("Get");
             getBtn.setBounds(50, 250, 80, 30);
             getBtn.addActionListener(this);
             add(getBtn);
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBounds(350, 50, 400, 350);
        add(scrollPane);

        updateDisplay();
    }

    public void actionPerformed(ActionEvent e) {
        CustomerManager manager = new CustomerManager();

        if (e.getSource() == saveBtn) {
            String name = nameField.getText();
            String phone = phoneField.getText();
            String room = (String) roomBox.getSelectedItem();

              if (!name.isEmpty() && !phone.isEmpty()) {
                Customer c = new Customer(name, phone, room);
                manager.saveCustomer(c);
                updateDisplay();
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Please fill all the fields");
            }

        } else if (e.getSource() == getBtn) {
            updateDisplay();
        }   if (e.getSource() == getBtn) {
            String name = nameField.getText();
            String phone = phoneField.getText();
            String room = (String) roomBox.getSelectedItem();

            if (!name.isEmpty() && !phone.isEmpty()) {
                Customer c = new Customer(name, phone, room);
                manager.saveCustomer(c);
                updateDisplay();
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Please fill all the fields");
            }

        } else if (e.getSource() == deleteBtn) {
            updateDisplay();
        }
    }

    private void updateDisplay() {
        displayArea.setText("");
        CustomerManager manager = new CustomerManager();
        ArrayList<Customer> list = manager.readCustomers();
        for (Customer c : list) {
            displayArea.append(c.toDisplay() + "\n");
        }
    }

    private void clearFields() {
        nameField.setText("");
        phoneField.setText("");
        roomBox.setSelectedIndex(0);
    }
}