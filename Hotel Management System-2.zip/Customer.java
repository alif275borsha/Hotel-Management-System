public class Customer {
    private String name;
    private String phone;
    private String roomType;

    public Customer(String name, String phone, String roomType) {
        this.name = name;
        this.phone = phone;
        this.roomType = roomType;
    }

    
    public String toString() {
        return name + "," + phone + "," + roomType;
    }

    public String toDisplay() {
        return "Name: " + name + "\nPhone: " + phone + "\nRoom: " + roomType + "\n";
    }
}