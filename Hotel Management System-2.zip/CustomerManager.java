import java.io.*;
import java.util.ArrayList;

public class CustomerManager {
    private String filepath = "Customers.txt";

    public void saveCustomer(Customer customer) {
        try (FileWriter fw = new FileWriter(filepath, true)) {
            fw.write(customer.toString() + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Customer> readCustomers() {
        ArrayList<Customer> customers = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 3) {
                    customers.add(new Customer(data[0].trim(), data[1].trim(), data[2].trim()));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return customers;
    }
}